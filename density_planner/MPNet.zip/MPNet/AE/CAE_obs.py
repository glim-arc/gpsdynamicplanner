import argparse
import os
import torch
from torch import nn
from mpnet_data.simulation_objects import StaticObstacle, Environment, DynamicObstacle
import numpy as np
import hyperparams


#https://medium.com/dataseries/convolutional-autoencoder-in-pytorch-on-mnist-dataset-d65145c132ac

class Encoder(nn.Module):
	def __init__(self):
		super(Encoder, self).__init__()

		#convolutional layer #1*240*400
		self.conv = self.encoder_cnn = nn.Sequential(
			#1*240*400
			nn.MaxPool2d(kernel_size=2, stride=2),
			# 1*120*200
            nn.Conv2d(1, 8, 5, stride=2, padding=1),
            nn.PReLU(),
			# 8*116*196
			nn.MaxPool2d(kernel_size=2, stride=2),
			# 8*58*98
            nn.Conv2d(8, 16, 5, stride=2, padding=1),
            nn.PReLU(),
			# 16*54*94
			nn.MaxPool2d(kernel_size=2, stride=2),
			# 16*27*47
			nn.Conv2d(16, 32, 5, stride=2, padding=0),
            nn.PReLU(),
			# 32*23*43
        )

		#flatten
		self.flatten = nn.Flatten(start_dim=1)

		#linear
		self.lin = nn.Sequential(nn.Linear(32*23*43, 2048),nn.PReLU(),nn.Linear(2048, 512),nn.PReLU(),nn.Linear(512, 128),nn.PReLU(),nn.Linear(128, 28))
			
	def forward(self, x):
		x = self.conv(x)
		x = self.flatten(x)
		x = self.lin(x)
		return x

class Decoder(nn.Module):
	def __init__(self, encoded_space_dim, fc2_input_dim):
		super().__init__()
		self.lin = nn.Sequential(nn.Linear(28, 128),nn.PReLU(),nn.Linear(128, 512),nn.PReLU(),nn.Linear(512, 2048),nn.PReLU(),nn.Linear(2048, 32*23*43))

		self.unflatten = nn.Unflatten(dim=1,unflattened_size=(32, 23, 43))

		self.deconv = nn.Sequential(
			nn.PReLU(True),
			nn.ConvTranspose2d(32, 16, 5, stride=2,
							   padding=0, output_padding=0),
			nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
			nn.PReLU(True),
			nn.ConvTranspose2d(16, 8, 5, stride=2,
							   padding=1, output_padding=1),
			nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
			nn.PReLU(True),
			nn.ConvTranspose2d(8, 1, 5, stride=2,
							   padding=1, output_padding=1),
			nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
		)

	def forward(self, x):
		x = self.lin(x)
		x = self.unflatten(x)
		x = self.deconv(x)
		return x

mse_loss = nn.MSELoss()
lam=1e-3
def loss_function(W, x, recons_x, h):
	mse = mse_loss(recons_x, x)
	"""
	W is shape of N_hidden x N. So, we do not need to transpose it as opposed to http://wiseodd.github.io/techblog/2016/12/05/contractive-autoencoder/
	"""
	dh = h*(1-h) # N_batch x N_hidden
	contractive_loss = torch.sum(Variable(W)**2, dim=1).sum().mul_(lam)
	return mse + contractive_loss

def load_env(i):
	### load hyperparameters
	args = hyperparams.parse_args()

	directory = "./mpnet_data/env/" + str(i)

	env_file = ""
	start_goal_file = ""

	files = os.listdir(directory)

	for file in files:
		if file[-3:] == "npy":
			if file.find("env_" + str(i) + ".npy") != -1:
				env_file = file

	obslist = np.load(directory + "/" + env_file, allow_pickle=True)

	objects = []
	for i in range(len(obslist)):
		obs, gps_dynamics = obslist[i]
		map = DynamicObstacle(args, name="gpsmaps%d" % i, coord=obs, velocity_x=gps_dynamics[1],
							  velocity_y=gps_dynamics[2],
							  gps_growthrate=gps_dynamics[0], isgps=True)
		objects.append(map)

	environment = Environment(objects, args)

	return environment.grid.numpy()

def main(args):	
	
	if not os.path.exists(args.model_path):
		os.makedirs(args.model_path)


	env_list = []

	for env_num in range(args.total_env_num):
		# load environment
		env_grid = load_env(env_num)
		env_list.append(env_list)

	env_list = np.array(env_list)

	encoder = Encoder()
	decoder = Decoder()
	device = "cpu"
	if torch.cuda.is_available():
		device = "cuda"
		encoder.to(device)
		decoder.to(device)


	params = list(encoder.parameters())+list(decoder.parameters())
	optimizer = torch.optim.Adam(params)
	total_loss=[]
	for epoch in range(args.num_epochs):
		print ("epoch" + str(epoch))
		avg_loss=0

		for env_num in range(0, args.total_env_num-100, args.batch_size):
			decoder.zero_grad()
			encoder.zero_grad()

			cur_grid_batch = []

			if i + args.batch_size < len(env_list):
				cur_grid_batch = env_list[i:i + args.batch_size]
			else:
				cur_grid_batch = env_list[i:]

			cur_grid_batch = torch.from_numpy(cur_grid_batch).to(device)

			# ===================forward=====================
			latent_space = encoder(cur_grid_batch)
			output = decoder(latent_space)
			keys=encoder.state_dict().keys()
			W=encoder.state_dict()['encoder.6.weight'] # regularize or contracting last layer of encoder. Print keys to displace the layers name. 
			loss = loss_function(W,cur_grid_batch,output,h)
			avg_loss=avg_loss+loss.data[0]
			# ===================backward====================
			loss.backward()
			optimizer.step()
		print ("--average loss:")
		print (avg_loss/(len(obs)/args.batch_size))
		total_loss.append(avg_loss/(len(obs)/args.batch_size))

	avg_loss=0
	for i in range(args.total_env_num-100, args.total_env_num, args.batch_size):
		cur_grid_batch = env_list[i:i+args.batch_size]
		cur_grid_batch = torch.from_numpy(cur_grid_batch).to(device)
		# ===================forward=====================
		output = encoder(cur_grid_batch)
		output = decoder(output)
		loss = mse_loss(output,cur_grid_batch)
		avg_loss=avg_loss+loss.data[0]
	print ("--Validation average loss:")
	print (avg_loss/(100/args.batch_size))

    
	torch.save(encoder.state_dict(),os.path.join(args.model_path,'cae_encoder.pkl'))
	torch.save(decoder.state_dict(),os.path.join(args.model_path,'cae_decoder.pkl'))
	torch.save(total_loss,'total_loss.dat')


if __name__ == '__main__':
	parser = argparse.ArgumentParser()

	# mpnet training data generation
	parser.add_argument('--gps_training_data_generation', type=bool, default=True)
	parser.add_argument('--gps_training_env_path', type=str, default="mpnet_data/env/")
	parser.add_argument('--total_env_num', type=int, default=500)
	parser.add_argument('--training_env_num', type=int, default=500)
	parser.add_argument('--training_traj_num', type=int, default=10)
	parser.add_argument('--model_path', type=str, default='./mpnet_data/models/',help='path for saving trained models')
	parser.add_argument('--num_epochs', type=int, default=400)
	parser.add_argument('--batch_size', type=int, default=10)
	parser.add_argument('--learning_rate', type=float, default=0.001)
	args = parser.parse_args()
	main(args)
